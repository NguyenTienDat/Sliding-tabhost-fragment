/** Automatically generated file. DO NOT MODIFY */
package com.tabs_swipe;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}